angular
  .module('app')
  .controller('ProfileController', ['$scope', '$state', function($scope,
      $state) {

  }]);
