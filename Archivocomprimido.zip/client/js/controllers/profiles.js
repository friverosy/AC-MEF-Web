angular
  .module('app')
  .controller('ProfilesController', ['$scope', '$state', function($scope,
      $state) {

  }]);
